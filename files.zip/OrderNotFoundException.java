/**
 * OrderNotFoundException.java
 * -----------------------------------------------------------
 * Custom checked exception thrown when a user tries to check
 * or update the status of an Order ID that does not exist.
 *
 * Demonstrates: Exception Handling (custom checked exception).
 * -----------------------------------------------------------
 */
public class OrderNotFoundException extends Exception {

    public OrderNotFoundException(String message) {
        super(message);
    }
}
