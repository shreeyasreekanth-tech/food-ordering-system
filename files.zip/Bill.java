/**
 * Bill.java
 * -----------------------------------------------------------
 * Responsible for generating a formatted bill/invoice for a
 * given Order and Customer. Kept as a separate class to follow
 * the Single Responsibility Principle (Order just holds data,
 * Bill formats/presents it).
 *
 * Demonstrates: Method Overloading (two generateBill versions),
 * Separation of concerns.
 * -----------------------------------------------------------
 */
public class Bill {

    private static final double TAX_RATE = 0.05; // 5% GST/tax

    // Overload 1: simple bill (no tax breakup shown)
    public String generateBill(Order order, Customer customer) {
        return generateBill(order, customer, false);
    }

    // Overload 2: detailed bill with tax breakup, pass true for tax breakup
    public String generateBill(Order order, Customer customer, boolean detailed) {
        StringBuilder sb = new StringBuilder();
        sb.append("=================================================\n");
        sb.append("                  ORDER BILL\n");
        sb.append("=================================================\n");
        sb.append("Order ID   : ").append(order.getOrderId()).append("\n");
        sb.append("Date/Time  : ").append(order.getOrderDateTime()).append("\n");
        sb.append("Customer   : ").append(customer.getName())
          .append(" (ID: ").append(customer.getCustomerId()).append(")\n");
        sb.append("Phone      : ").append(customer.getPhoneNumber()).append("\n");
        sb.append("Address    : ").append(customer.getAddress()).append("\n");
        sb.append("-------------------------------------------------\n");
        sb.append(String.format("%-22s %-6s %-10s%n", "Item", "Qty", "Subtotal"));
        sb.append("-------------------------------------------------\n");

        for (OrderItem item : order.getOrderItems()) {
            sb.append(String.format("%-22s x%-5d Rs.%-8.2f%n",
                    item.getFoodItem().getItemName(),
                    item.getQuantity(),
                    item.getSubtotal()));
        }

        sb.append("-------------------------------------------------\n");

        double subTotal = order.getTotalAmount();

        if (detailed) {
            double tax = subTotal * TAX_RATE;
            double grandTotal = subTotal + tax;
            sb.append(String.format("Sub Total           : Rs.%.2f%n", subTotal));
            sb.append(String.format("Tax (5%%)            : Rs.%.2f%n", tax));
            sb.append(String.format("Grand Total         : Rs.%.2f%n", grandTotal));
        } else {
            sb.append(String.format("Total Amount        : Rs.%.2f%n", subTotal));
        }

        sb.append("Order Status        : ").append(order.getStatus()).append("\n");
        sb.append("=================================================\n");

        return sb.toString();
    }
}
