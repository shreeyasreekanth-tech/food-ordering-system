import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * FoodOrderingSystem.java
 * -----------------------------------------------------------
 * The core "backend" / service class of the application.
 * Holds all in-memory "database" collections (HashMap/ArrayList)
 * and implements all business logic:
 *   - Menu management
 *   - Customer registration
 *   - Cart handling
 *   - Order placement & ID generation
 *   - Order status management
 *   - Validation & exception handling
 *
 * Demonstrates: Use of Java Collections (HashMap, ArrayList),
 * Encapsulation, Exception Handling.
 * -----------------------------------------------------------
 */
public class FoodOrderingSystem {

    // ---------------- "Database" (in-memory collections) ----------------
    private Map<Integer, FoodItem> menu;        // Item ID -> FoodItem
    private Map<Integer, Customer> customers;   // Customer ID -> Customer
    private Map<Integer, Order> orders;         // Order ID -> Order

    // Auto-incrementing ID counters
    private int nextCustomerId;
    private int nextOrderId;

    public FoodOrderingSystem() {
        menu = new HashMap<>();
        customers = new HashMap<>();
        orders = new HashMap<>();
        nextCustomerId = 1;
        nextOrderId = 1001; // order IDs start from 1001 for a nicer look
        loadPredefinedMenu();
    }

    // ---------------- Menu Handling ----------------

    // Pre-loads some sample food items into the menu ("database")
    private void loadPredefinedMenu() {
        menu.put(1, new FoodItem(1, "Veg Burger", 99.00, "Fast Food"));
        menu.put(2, new FoodItem(2, "Chicken Burger", 149.00, "Fast Food"));
        menu.put(3, new FoodItem(3, "Margherita Pizza", 249.00, "Pizza"));
        menu.put(4, new FoodItem(4, "Farmhouse Pizza", 329.00, "Pizza"));
        menu.put(5, new FoodItem(5, "Paneer Butter Masala", 219.00, "Main Course"));
        menu.put(6, new FoodItem(6, "Chicken Biryani", 259.00, "Main Course"));
        menu.put(7, new FoodItem(7, "French Fries", 89.00, "Snacks"));
        menu.put(8, new FoodItem(8, "Cold Coffee", 79.00, "Beverages"));
        menu.put(9, new FoodItem(9, "Masala Dosa", 109.00, "South Indian"));
        menu.put(10, new FoodItem(10, "Gulab Jamun", 59.00, "Dessert"));
    }

    // Displays the full menu in a formatted table
    public void displayMenu() {
        System.out.println("\n================= FOOD MENU =================");
        System.out.printf("%-6s %-22s %-12s %-12s%n", "ID", "Item Name", "Price", "Category");
        System.out.println("-----------------------------------------------");
        // Sorted by item ID for a clean, predictable display
        List<Integer> ids = new ArrayList<>(menu.keySet());
        java.util.Collections.sort(ids);
        for (int id : ids) {
            System.out.println(menu.get(id));
        }
        System.out.println("===============================================");
    }

    // Validates and returns a FoodItem by ID; throws if not found
    public FoodItem getFoodItem(int itemId) throws InvalidItemException {
        FoodItem item = menu.get(itemId);
        if (item == null) {
            throw new InvalidItemException("Invalid Item ID: " + itemId + " does not exist in the menu.");
        }
        return item;
    }

    // ---------------- Customer Handling ----------------

    // Registers a new customer and returns the generated Customer object
    public Customer registerCustomer(String name, String phone, String address) {
        Customer customer = new Customer(nextCustomerId, name, phone, address);
        customers.put(nextCustomerId, customer);
        nextCustomerId++;
        return customer;
    }

    public Customer getCustomer(int customerId) {
        return customers.get(customerId);
    }

    // ---------------- Cart Handling ----------------

    // Adds an item+quantity to the given cart (Map: itemId -> quantity).
    // Validates both the item ID and the quantity before adding.
    public void addToCart(Map<Integer, Integer> cart, int itemId, int quantity)
            throws InvalidItemException, InvalidQuantityException {

        // Validate item exists
        getFoodItem(itemId); // throws InvalidItemException if not found

        // Validate quantity
        if (quantity <= 0) {
            throw new InvalidQuantityException("Quantity must be greater than zero. Given: " + quantity);
        }

        // If item already in cart, increase quantity; else add new entry
        cart.merge(itemId, quantity, Integer::sum);
    }

    // Displays the current contents of the cart along with a running total
    public void viewCart(Map<Integer, Integer> cart) {
        if (cart.isEmpty()) {
            System.out.println("Your cart is empty.");
            return;
        }
        System.out.println("\n---------------- YOUR CART ----------------");
        System.out.printf("%-22s %-6s %-10s%n", "Item", "Qty", "Subtotal");
        System.out.println("--------------------------------------------");
        double total = 0.0;
        for (Map.Entry<Integer, Integer> entry : cart.entrySet()) {
            FoodItem item = menu.get(entry.getKey());
            int qty = entry.getValue();
            double subtotal = item.getPrice() * qty;
            total += subtotal;
            System.out.printf("%-22s x%-5d Rs.%-8.2f%n", item.getItemName(), qty, subtotal);
        }
        System.out.println("--------------------------------------------");
        System.out.printf("Cart Total: Rs.%.2f%n", total);
        System.out.println("============================================");
    }

    // ---------------- Order Handling ----------------

    // Places an order for the given customer using items currently in the cart.
    public Order placeOrder(int customerId, Map<Integer, Integer> cart) throws InvalidItemException {
        if (cart.isEmpty()) {
            throw new IllegalStateException("Cannot place an order with an empty cart.");
        }

        Order order = new Order(nextOrderId, customerId);

        for (Map.Entry<Integer, Integer> entry : cart.entrySet()) {
            FoodItem foodItem = getFoodItem(entry.getKey()); // re-validate before order
            OrderItem orderItem = new OrderItem(foodItem, entry.getValue());
            order.addOrderItem(orderItem);
        }

        orders.put(nextOrderId, order);
        nextOrderId++;

        cart.clear(); // empty the cart after placing the order
        return order;
    }

    // Retrieves an order by ID; throws if not found
    public Order getOrder(int orderId) throws OrderNotFoundException {
        Order order = orders.get(orderId);
        if (order == null) {
            throw new OrderNotFoundException("Order ID " + orderId + " was not found.");
        }
        return order;
    }

    // Checks (returns) the current status of an order
    public OrderStatus checkOrderStatus(int orderId) throws OrderNotFoundException {
        return getOrder(orderId).getStatus();
    }

    // Updates the status of an existing order (e.g., PENDING -> PREPARING -> DELIVERED)
    public void updateOrderStatus(int orderId, OrderStatus newStatus) throws OrderNotFoundException {
        Order order = getOrder(orderId);
        order.setStatus(newStatus);
    }

    // Returns all orders placed by a specific customer
    public List<Order> getOrdersByCustomer(int customerId) {
        List<Order> result = new ArrayList<>();
        for (Order order : orders.values()) {
            if (order.getCustomerId() == customerId) {
                result.add(order);
            }
        }
        return result;
    }
}
