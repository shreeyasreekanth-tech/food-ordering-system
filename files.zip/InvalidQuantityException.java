/**
 * InvalidQuantityException.java
 * -----------------------------------------------------------
 * Custom checked exception thrown when a user enters a
 * quantity that is zero, negative, or otherwise invalid.
 *
 * Demonstrates: Exception Handling (custom checked exception).
 * -----------------------------------------------------------
 */
public class InvalidQuantityException extends Exception {

    public InvalidQuantityException(String message) {
        super(message);
    }
}
