/**
 * InvalidItemException.java
 * -----------------------------------------------------------
 * Custom checked exception thrown when a user enters a food
 * item ID that does not exist in the menu.
 *
 * Demonstrates: Exception Handling (custom checked exception),
 * Inheritance (extends Exception).
 * -----------------------------------------------------------
 */
public class InvalidItemException extends Exception {

    // Constructor that accepts a custom error message
    public InvalidItemException(String message) {
        super(message); // pass message to the parent Exception class
    }
}
