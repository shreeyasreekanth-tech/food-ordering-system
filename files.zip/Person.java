/**
 * Person.java
 * -----------------------------------------------------------
 * Abstract base class representing a generic person in the
 * system. Customer extends this class.
 *
 * Demonstrates: Abstraction, Inheritance, Polymorphism
 * (the abstract displayInfo() method is overridden by Customer).
 * -----------------------------------------------------------
 */
public abstract class Person {

    protected int id;
    protected String name;

    public Person(int id, String name) {
        this.id = id;
        this.name = name;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    // Abstract method - every subclass must provide its own implementation.
    // This enables runtime polymorphism.
    public abstract void displayInfo();
}
