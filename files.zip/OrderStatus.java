/**
 * OrderStatus.java
 * -----------------------------------------------------------
 * Enum representing the life cycle of an Order.
 * Using an enum (instead of plain Strings) gives compile-time
 * safety and avoids invalid status values.
 * -----------------------------------------------------------
 */
public enum OrderStatus {
    PENDING,    // Order has been placed but not yet started
    PREPARING,  // Kitchen is preparing the order
    DELIVERED   // Order has been delivered to the customer
}
