/**
 * OrderItem.java
 * -----------------------------------------------------------
 * Represents one line item inside an Order: a FoodItem
 * together with the quantity ordered. An Order holds a list
 * of OrderItem objects.
 *
 * Demonstrates: Composition (has-a FoodItem), Encapsulation.
 * -----------------------------------------------------------
 */
public class OrderItem {

    private FoodItem foodItem;
    private int quantity;

    public OrderItem(FoodItem foodItem, int quantity) {
        this.foodItem = foodItem;
        this.quantity = quantity;
    }

    public FoodItem getFoodItem() {
        return foodItem;
    }

    public void setFoodItem(FoodItem foodItem) {
        this.foodItem = foodItem;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    // Calculates the subtotal for this line item (price * quantity)
    public double getSubtotal() {
        return foodItem.getPrice() * quantity;
    }

    @Override
    public String toString() {
        return String.format("%-22s x%-4d Rs.%-10.2f", foodItem.getItemName(),
                quantity, getSubtotal());
    }
}
