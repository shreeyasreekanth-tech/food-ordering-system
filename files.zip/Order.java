import java.util.ArrayList;
import java.util.List;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 * Order.java
 * -----------------------------------------------------------
 * Represents a complete customer order: a unique Order ID,
 * the Customer who placed it, the list of OrderItems,
 * the total amount and the current OrderStatus.
 *
 * Demonstrates: Encapsulation, Composition (has-a List of
 * OrderItem), use of ArrayList collection.
 * -----------------------------------------------------------
 */
public class Order {

    private int orderId;
    private int customerId;
    private List<OrderItem> orderItems;
    private double totalAmount;
    private OrderStatus status;
    private String orderDateTime;

    public Order(int orderId, int customerId) {
        this.orderId = orderId;
        this.customerId = customerId;
        this.orderItems = new ArrayList<>();
        this.totalAmount = 0.0;
        this.status = OrderStatus.PENDING; // every new order starts as PENDING
        this.orderDateTime = LocalDateTime.now()
                .format(DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss"));
    }

    // Adds a line item to the order and recalculates the total
    public void addOrderItem(OrderItem item) {
        orderItems.add(item);
        calculateTotal();
    }

    // Recalculates total amount by summing all line-item subtotals
    public void calculateTotal() {
        double total = 0.0;
        for (OrderItem item : orderItems) {
            total += item.getSubtotal();
        }
        this.totalAmount = total;
    }

    public int getOrderId() {
        return orderId;
    }

    public int getCustomerId() {
        return customerId;
    }

    public List<OrderItem> getOrderItems() {
        return orderItems;
    }

    public double getTotalAmount() {
        return totalAmount;
    }

    public OrderStatus getStatus() {
        return status;
    }

    public void setStatus(OrderStatus status) {
        this.status = status;
    }

    public String getOrderDateTime() {
        return orderDateTime;
    }

    @Override
    public String toString() {
        return "Order #" + orderId + " | Customer ID: " + customerId +
                " | Total: Rs." + String.format("%.2f", totalAmount) +
                " | Status: " + status + " | Placed: " + orderDateTime;
    }
}
