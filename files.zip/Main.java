import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

/**
 * Main.java
 * -----------------------------------------------------------
 * Entry point of the application. Provides a menu-driven
 * console interface (the "frontend") that talks to the
 * FoodOrderingSystem backend.
 *
 * Run this class to start the program.
 * -----------------------------------------------------------
 */
public class Main {

    private static Scanner sc = new Scanner(System.in);
    private static FoodOrderingSystem system = new FoodOrderingSystem();
    private static Bill billGenerator = new Bill();

    // Current logged-in customer and their active cart (session state)
    private static Customer currentCustomer = null;
    private static Map<Integer, Integer> cart = new HashMap<>();

    public static void main(String[] args) {

        System.out.println("=====================================================");
        System.out.println("   WELCOME TO THE ONLINE FOOD ORDERING SYSTEM (OFOS)");
        System.out.println("=====================================================");

        loginOrRegisterCustomer();

        boolean running = true;
        while (running) {
            printMainMenu();
            int choice = readInt("Enter your choice: ");

            switch (choice) {
                case 1:
                    system.displayMenu();
                    break;
                case 2:
                    selectFoodItem();
                    break;
                case 3:
                    addAnotherItemLoop();
                    break;
                case 4:
                    system.viewCart(cart);
                    break;
                case 5:
                    placeOrderFlow();
                    break;
                case 6:
                    checkOrderStatusFlow();
                    break;
                case 7:
                    running = false;
                    System.out.println("\nThank you for using OFOS. Have a tasty day!");
                    break;
                default:
                    System.out.println("Invalid choice! Please enter a number between 1 and 7.");
            }
        }
        sc.close();
    }

    // ---------------- Menu Display ----------------
    private static void printMainMenu() {
        System.out.println("\n-------------------- MAIN MENU --------------------");
        System.out.println("1. Display Food Menu");
        System.out.println("2. Select Food Item & Quantity (Add to Cart)");
        System.out.println("3. Add Multiple Items to Cart");
        System.out.println("4. View Cart Details");
        System.out.println("5. Place Order");
        System.out.println("6. Check Order Status");
        System.out.println("7. Exit");
        System.out.println("-----------------------------------------------------");
    }

    // ---------------- Customer Login / Registration ----------------
    private static void loginOrRegisterCustomer() {
        System.out.println("\nLet's get your details for delivery purposes.");
        System.out.print("Enter your Name: ");
        String name = sc.nextLine();
        System.out.print("Enter your Phone Number: ");
        String phone = sc.nextLine();
        System.out.print("Enter your Delivery Address: ");
        String address = sc.nextLine();

        currentCustomer = system.registerCustomer(name, phone, address);
        System.out.println("\nRegistration successful! Your Customer ID is: "
                + currentCustomer.getCustomerId());
    }

    // ---------------- Option 2: Select single food item ----------------
    private static void selectFoodItem() {
        system.displayMenu();
        int itemId = readInt("Enter Item ID to add to cart: ");
        int qty = readInt("Enter Quantity: ");

        try {
            system.addToCart(cart, itemId, qty);
            System.out.println("Item added to cart successfully!");
        } catch (InvalidItemException | InvalidQuantityException e) {
            // Exception handling: invalid item ID or invalid quantity
            System.out.println("Error: " + e.getMessage());
        }
    }

    // ---------------- Option 3: Add multiple items in one go ----------------
    private static void addAnotherItemLoop() {
        system.displayMenu();
        boolean addMore = true;
        while (addMore) {
            int itemId = readInt("Enter Item ID (or -1 to stop adding): ");
            if (itemId == -1) {
                addMore = false;
                continue;
            }
            int qty = readInt("Enter Quantity: ");
            try {
                system.addToCart(cart, itemId, qty);
                System.out.println("Added! Add another item or enter -1 to stop.");
            } catch (InvalidItemException | InvalidQuantityException e) {
                System.out.println("Error: " + e.getMessage() + " Please try again.");
            }
        }
        system.viewCart(cart);
    }

    // ---------------- Option 5: Place Order ----------------
    private static void placeOrderFlow() {
        if (cart.isEmpty()) {
            System.out.println("Your cart is empty! Add items before placing an order.");
            return;
        }
        try {
            Order order = system.placeOrder(currentCustomer.getCustomerId(), cart);
            System.out.println("\nOrder placed successfully! Your Order ID is: " + order.getOrderId());

            // Automatically generate and display the bill
            String bill = billGenerator.generateBill(order, currentCustomer, true);
            System.out.println(bill);
        } catch (InvalidItemException e) {
            System.out.println("Order could not be placed: " + e.getMessage());
        } catch (IllegalStateException e) {
            System.out.println(e.getMessage());
        }
    }

    // ---------------- Option 6: Check Order Status ----------------
    private static void checkOrderStatusFlow() {
        List<Order> myOrders = system.getOrdersByCustomer(currentCustomer.getCustomerId());
        if (myOrders.isEmpty()) {
            System.out.println("You have not placed any orders yet.");
            return;
        }

        System.out.println("\nYour Orders:");
        for (Order o : myOrders) {
            System.out.println(o);
        }

        int orderId = readInt("\nEnter Order ID to check status: ");
        try {
            OrderStatus status = system.checkOrderStatus(orderId);
            System.out.println("Status of Order #" + orderId + " is: " + status);

            // Simple admin-style simulation: allow advancing the order status
            System.out.print("Would you like to simulate the next status update? (y/n): ");
            String resp = sc.nextLine().trim().toLowerCase();
            if (resp.equals("y")) {
                advanceOrderStatus(orderId, status);
            }
        } catch (OrderNotFoundException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    // Helper to move an order from PENDING -> PREPARING -> DELIVERED
    private static void advanceOrderStatus(int orderId, OrderStatus current) {
        try {
            OrderStatus next;
            switch (current) {
                case PENDING:
                    next = OrderStatus.PREPARING;
                    break;
                case PREPARING:
                    next = OrderStatus.DELIVERED;
                    break;
                default:
                    System.out.println("Order is already DELIVERED. No further updates possible.");
                    return;
            }
            system.updateOrderStatus(orderId, next);
            System.out.println("Order #" + orderId + " status updated to: " + next);
        } catch (OrderNotFoundException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    // ---------------- Input Helper ----------------
    // Reads an integer safely, re-prompting on invalid (non-numeric) input
    private static int readInt(String prompt) {
        while (true) {
            System.out.print(prompt);
            String input = sc.nextLine().trim();
            try {
                return Integer.parseInt(input);
            } catch (NumberFormatException e) {
                System.out.println("Invalid input! Please enter a whole number.");
            }
        }
    }
}
