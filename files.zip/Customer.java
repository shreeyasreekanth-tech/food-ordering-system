/**
 * Customer.java
 * -----------------------------------------------------------
 * Represents a customer of the food ordering system.
 * Extends the abstract Person class.
 *
 * Demonstrates: Inheritance (extends Person), Polymorphism
 * (overrides displayInfo()), Encapsulation, Method Overloading
 * (two constructors).
 * -----------------------------------------------------------
 */
public class Customer extends Person {

    private String phoneNumber;
    private String address;

    // Constructor 1: full details
    public Customer(int customerId, String name, String phoneNumber, String address) {
        super(customerId, name); // call Person's constructor
        this.phoneNumber = phoneNumber;
        this.address = address;
    }

    // Constructor 2 (Overloaded): address optional, defaults to "Not Provided"
    public Customer(int customerId, String name, String phoneNumber) {
        this(customerId, name, phoneNumber, "Not Provided");
    }

    public int getCustomerId() {
        return id; // inherited field from Person
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    // Polymorphism: overriding the abstract method from Person
    @Override
    public void displayInfo() {
        System.out.println("Customer ID : " + id);
        System.out.println("Name        : " + name);
        System.out.println("Phone       : " + phoneNumber);
        System.out.println("Address     : " + address);
    }

    @Override
    public String toString() {
        return "Customer{ID=" + id + ", Name=" + name +
                ", Phone=" + phoneNumber + ", Address=" + address + "}";
    }
}
