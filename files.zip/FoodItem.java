/**
 * FoodItem.java
 * -----------------------------------------------------------
 * Represents a single food item available on the menu.
 * Stores Item ID, Name, Price and Category.
 *
 * Demonstrates: Encapsulation (private fields + getters/setters),
 * Method Overloading (two constructors), toString() override.
 * -----------------------------------------------------------
 */
public class FoodItem {

    private int itemId;
    private String itemName;
    private double price;
    private String category;

    // Constructor 1: full details provided
    public FoodItem(int itemId, String itemName, double price, String category) {
        this.itemId = itemId;
        this.itemName = itemName;
        this.price = price;
        this.category = category;
    }

    // Constructor 2 (Overloaded): default category "General" when not provided
    public FoodItem(int itemId, String itemName, double price) {
        this(itemId, itemName, price, "General"); // constructor chaining
    }

    // ----------- Getters and Setters (Encapsulation) -----------
    public int getItemId() {
        return itemId;
    }

    public void setItemId(int itemId) {
        this.itemId = itemId;
    }

    public String getItemName() {
        return itemName;
    }

    public void setItemName(String itemName) {
        this.itemName = itemName;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    // Overridden toString() to neatly display a menu row
    @Override
    public String toString() {
        return String.format("%-6d %-22s Rs.%-10.2f %-12s",
                itemId, itemName, price, category);
    }
}
